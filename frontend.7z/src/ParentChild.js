// import React, { useState } from 'react' 
// import ReactDOM from 'react-dom' 
// const ParentComponent = () => { 
//     const [stateVariable, setStateVariable] = useState('this is the starting value for the variable'); 
//     return ( 
//         <div> 
//             <h1>This is a function component view</h1>
//             <ChildComponent exampleProp={stateVariable} />
//         </div> 
//     ) 
// } 
// const ChildComponent = (props) => {
//     return (
//         <div>
//             <h2>{props.exampleProp}</h2>
//         </div>
//     )
// }
// ReactDOM.render( <ParentComponent />, document.getElementById('app') );
// export default ParentComponent;